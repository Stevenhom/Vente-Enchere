﻿using System;

namespace Programmation
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 25; i++) 
            {
                Console.WriteLine("Venhom");
            }
        }
    }
}
