sqlcmd -S localhost\sqlexpress -E
drop database enchere;
go
create database enchere;
go

create table admin(
	id int primary key,
	nom varchar(20),
	email varchar(20),
	mdp varchar(20)
);
go

create table produit(
	id int primary key,
	nom varchar(20),
	prixNormal float,
	prixMax float,
	vendu int,
	CONSTRAINT testbool CHECK (vendu IN (1,0))
);
go

create table client(
	id int primary key,
	nom varchar(20),
	email varchar(20),
	mdp varchar(20)
);
go

create table vente(
	idProduit int,
	idClient int,
	prixEnchere float,
	dateVente datetime default current_timestamp not null,
	dateExpiree datetime,
	foreign key (idProduit) references produit(id),
	foreign key (idClient) references client(id)
);
go

insert into admin values('1','Jean','jeje@gmail.com','123456');
go
insert into produit values('1','vase','5000','10000','0');
go
insert into client values('1','Naej','nana@gmail.com','654321');
go
insert into client values('2','Jin','jiji@gmail.com','111111');
go
insert into vente values('1','1','3000',default,' 2022-04-30 12:00:00');
go

